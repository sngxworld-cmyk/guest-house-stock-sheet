
# Guest House Stock Sheet

## How to Run

### Requirements
- Node.js (LTS)
- Internet browser (Chrome recommended)

### Backend
cd backend
npm install
npm start

### Frontend
cd frontend
npm install
npm start

The app will open in your browser.
You can install it as an app from the browser menu.
