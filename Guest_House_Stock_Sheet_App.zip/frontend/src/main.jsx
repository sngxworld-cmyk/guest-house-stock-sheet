
import React from 'react';
import ReactDOM from 'react-dom/client';

function App(){
  return (
    <div style={{padding:20}}>
      <h1>Guest House Stock Sheet</h1>
      <p>Production app scaffold ready.</p>
      <p>Main spreadsheet, AI bot, and logic engines will run here.</p>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
